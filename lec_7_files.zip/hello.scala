// Examples largely taken from Programming in Scala, 3rd Edition
// by Venners, Spoon, and Odersky
//
// Be sure to practice with them in the Scala Interpreter
println("Hello, world!")
1 + 2
res0 * 3
val msg = "Hello, world!"
msg = "Goodbye, world"  // Should fail because "val" is not modifiable
var varmsg = "Hello, world"
varmsg = "Goodbye, world"
val msg = "Hello, world!"
val msg2: java.lang.String = "Hello again, world!"
val msg3: String = "Hello yet again, world!"

def max(x: Int, y: Int): Int = {
           if (x > y) x
           else y
         }

max(3,5)

def max2(x: Int, y: Int) = if (x > y) x else y

def greet() = println("Hello, world!")

val big = new java.math.BigInteger("1234567890")

val greetStrings = new Array[String](3)
greetStrings(0) = "Hello" 
greetStrings(1) = ", "
greetStrings(2) = "world"


// "Java-style" loop. OK, but not functional
var i = 0;
while (i < greetStrings.length) {
  if (i != 0) {
    print(" ");
  }
  print(greetStrings(i));
  i += 1;
}
println();

// More scala-like approaches
greetStrings.foreach(arg => println(arg))

greetStrings.foreach((arg: String) => println(arg))

greetStrings.foreach(println)

for (arg <- greetStrings)
    println(arg)

// Everything is a method call
(2).+(3)

println(greetStrings.apply(1))
greetStrings(0) = "Goodbye"
greetStrings.update(0, "Goodbye")

val numNames = Array("zero", "one", "two")
val numNames2 = Array.apply("zero", "one", "two")

// Functional programming: Methods should not have side effects
// As opposed to Array, List is an immutable list
val oneTwoThree = List(1, 2, 3)
oneTwoThree(1) = 3

val oneTwo = List(1, 2)
val threeFour = List(3, 4)
val oneTwoThreeFour = oneTwo ::: threeFour
println(oneTwo + " and " + threeFour + " were not mutated.")
println("Thus, " + oneTwoThreeFour + " is a new list.")

val twoThree = List(2, 3)
val oneTwoThree = 1 :: twoThree
println(oneTwoThree)

oneTwoThree.map(s => s + 2)

val pair = (99, "Luftballons")
println(pair._1)
println(pair._2)

var jetSet = Set("Boeing", "Airbus")
jetSet += "Lear"
println(jetSet.contains("Cessna"))

import scala.collection.mutable
  
val movieSet = mutable.Set("Hitch", "Poltergeist")
movieSet += "Shrek"
println(movieSet) 

val romanNumeral = Map(
    1 -> "I", 2 -> "II", 3 -> "III", 4 -> "IV", 5 -> "V"
)
println(romanNumeral(4))

val treasureMap = mutable.Map[Int, String]()
treasureMap += (1 -> "Go to island.")
treasureMap += (2 -> "Find big X on ground.")
treasureMap += (3 -> "Dig.")
println(treasureMap(2))

