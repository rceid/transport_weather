// Launch the spark shell with all jars needed by your tables. E.g.,
// spark-shell --jars IW-1.0-SNAPSHOT.jar

// Remember to use your cnet ids instead of spertus in the examples below

val textFile = sc.textFile("hdfs:///tmp/gutenberg/books.txt")

// Note dot positioning (so that the spark shell knows the line isn't complete)
val counts = textFile.flatMap(line => line.split(" ")).  
                      map(word => (word, 1)).
                      reduceByKey(_ + _)
counts.saveAsTextFile("hdfs:///tmp/spertus/spark_wc")

// Opening hive tables as spark dataframes
val stations = spark.table("stations")
stations.take(5)
stations.show(2)
val ontime = spark.table("ontime")
val ws = spark.table("weathersummary")

////////////////////////////////////////////////////
// "Hive-style" reimplementation of batch layer
//
// spark.sql is almost identical to hql, so these are the same as before
val dlys = spark.sql("""select t.year as year, t.month as month, t.dayofmonth as day,
  t.carrier as carrier, t.flightnum as flight,
  t.origin as origin_name, t.origincityname as origin_city, so.code as origin_code, t.depdelay as dep_delay,
  t.dest as dest_name, t.destcityname as dest_city, sd.code as dest_code, t.arrdelay as arr_delay
  from ontime t join stations so join stations sd
    on t.origin = so.name and t.dest = sd.name""") 

// Make a spark dataframe visible to spark.sql
  dlys.createOrReplaceTempView("dlys")
  val faw_h = spark.sql("""select d.year as year, d.month as month, d.day as day, d.carrier as carrier, d.flight as flight,
	d.origin_name as origin_name, d.origin_city as origin_city, d.origin_code as origin_code, d.dep_delay as dep_delay,
	d.dest_name as dest_name, d.dest_city as dest_city, d.dest_code as dest_code, d.arr_delay as arr_delay,
	w.meantemperature as mean_temperature, w.meanvisibility as mean_visibility, w.meanwindspeed as mean_windspeed,
	w.fog as fog, w.rain as rain, w.snow as snow, w.hail as hail, w.thunder as thunder, w.tornado as tornado,
	if(w.fog,d.dep_delay,0) as fog_delay, if(w.rain,d.dep_delay,0) as rain_delay, if(w.snow, d.dep_delay, 0) as snow_delay,
	if(w.hail, d.dep_delay, 0) as hail_delay, if(w.thunder, d.dep_delay, 0) as thunder_delay,
	if(w.tornado,  d.dep_delay, 0) as tornado_delay,
	if(w.fog or w.rain or w.snow or w.hail or w.thunder or w.tornado, 0, d.dep_delay) as clear_delay
	from dlys d join weathersummary w
	  on d.year = w.year and d.month = w.month and d.day = w.day and d.origin_code = w.station""")
  dlys.createOrReplaceTempView("faw_h")

val route_delays_h = spark.sql("""  select origin_name, dest_name, count(1),
  count(if(fog, 1, null)), sum(fog_delay),
  count(if(rain, 1, null)), sum(rain_delay),
  count(if(snow, 1, null)), sum(snow_delay),
  count(if(hail, 1, null)), sum(hail_delay),
  count(if(thunder, 1, null)), sum(thunder_delay),
  count(if(tornado, 1, null)), sum(tornado_delay),
  count(if(!fog and !rain and !snow and !hail and !thunder and !tornado, 1, null)), sum(clear_delay)
  from faw_h
  group by origin_name, dest_name""")

// Save to Hive because bulk loading HBase from Spark is awkward
import org.apache.spark.sql.SaveMode
route_delays_h.write.mode(SaveMode.Overwrite).saveAsTable("Spark_Route_Delays_HiveStyle")

////////////////////////////////////////////////////////////////
// "Object-oriented-style" reimplementation of our batch layer
//
// SQL commands are methods
 val delays_oo = ontime.join(stations, ontime("origin") <=> stations("name")).
			select(ontime("year"), ontime("month"), ontime("dayofmonth").as("day"), 
				   ontime("origin"), ontime("dest"), stations("code"), ontime("depdelay"))
			
  // First, join the delays with the weather
  val dw_oo = delays_oo.join(ws, delays_oo("code") <=> ws("station") && 
						  delays_oo("year") <=> ws("year") &&
						  delays_oo("month") <=> ws("month") &&
						  delays_oo("day") <=> ws("day"))
						  
  // Now build the final column set. Notice how SQL "if" becomes "when" 
  val faw_oo = dw_oo.select(delays_oo("year"), delays_oo("month"), delays_oo("day"), 
			delays_oo("origin").as("origin_name"), delays_oo("dest").as("dest_name"),
			dw_oo("fog"), when(dw_oo("fog"), dw_oo("depdelay")).otherwise(0).as("fog_delay"),
			dw_oo("rain"), when(dw_oo("rain"), dw_oo("depdelay")).otherwise(0).as("rain_delay"),
			dw_oo("snow"), when(dw_oo("snow"), dw_oo("depdelay")).otherwise(0).as("snow_delay"),
			dw_oo("hail"), when(dw_oo("hail"), dw_oo("depdelay")).otherwise(0).as("hail_delay"),
			dw_oo("thunder"), when(dw_oo("thunder"), dw_oo("depdelay")).otherwise(0).as("thunder_delay"),
			dw_oo("tornado"), when(dw_oo("tornado"), dw_oo("depdelay")).otherwise(0).as("tornado_delay"),
			when (dw_oo("fog").or(dw_oo("rain")).or(dw_oo("snow")).or(dw_oo("hail")).or(dw_oo("thunder")).or(dw_oo("tornado")), 0).otherwise(dw_oo("depdelay")).as("clear_delay"))

val route_delays_oo = faw_oo.groupBy(faw_oo("origin_name"), faw_oo("dest_name")).
            agg(sum(when(faw_oo("fog"), 1).otherwise(0)).as("fog_flights"), sum(faw_oo("fog_delay")).as("fog_delays"),
                sum(when(faw_oo("rain"), 1).otherwise(0)).as("rain_flights"), sum(faw_oo("rain_delay")).as("rain_delays"),
                sum(when(faw_oo("snow"), 1).otherwise(0)).as("snow_flights"), sum(faw_oo("snow_delay")).as("snow_delays"),
                sum(when(faw_oo("hail"), 1).otherwise(0)).as("hail_flights"), sum(faw_oo("hail_delay")).as("hail_delays"),
                sum(when(faw_oo("thunder"), 1).otherwise(0)).as("thunder_flights"), sum(faw_oo("thunder_delay")).as("thunder_delays"),
                sum(when(faw_oo("tornado"), 1).otherwise(0)).as("tornado_flights"), sum(faw_oo("tornado_delay")).as("tornado_delays"),
                sum(when (faw_oo("fog").or(faw_oo("rain")).or(faw_oo("snow")).or(faw_oo("hail")).or(faw_oo("thunder")).or(faw_oo("tornado")), 0).otherwise(1)).as("clear_flights"),
                sum(faw_oo("clear_delay")).as("clear_delays"))

route_delays_oo.write.mode(SaveMode.Overwrite).saveAsTable("Spark_Route_Delays_OOStyle")
